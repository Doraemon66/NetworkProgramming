﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Windows.Forms;


namespace TeacherMachine
{
    public class myServer
    {

        private static IPAddress GroupAddress = IPAddress.Parse("224.5.6.7");
        private static int GroupPort = 11002;
        private UdpClient myUdpClient = null;
        private IPEndPoint GroupEP = null;

        public myServer()
        {

            try
            {
                myUdpClient = new UdpClient();
            }
            catch (Exception e)
            {
                MessageBox.Show("udp new fail:" + e.ToString());
            }
            myUdpClient.JoinMulticastGroup(GroupAddress);
            GroupEP = new IPEndPoint(GroupAddress, GroupPort);


            //UdpClient client = new UdpClient(5566);
            //client.JoinMulticastGroup(IPAddress.Parse("234.5.6.7"));
            //IPEndPoint multicast = new IPEndPoint(IPAddress.Parse("234.5.6.7"), 7788);



        }

        public void mySend(byte[] send_data)
        {
            if (myUdpClient == null)
            {
                return;
            }

            try
            {
                myUdpClient.Send(send_data, send_data.Length, GroupEP);
            }
            catch (Exception e)
            {
                return;
            }

        }


    }

}
