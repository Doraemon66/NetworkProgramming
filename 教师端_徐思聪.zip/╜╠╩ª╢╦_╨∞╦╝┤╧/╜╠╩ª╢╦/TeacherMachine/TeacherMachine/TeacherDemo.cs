﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using ScreenshotCaptureWithMouse.ScreenCapture;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Threading;
using System.IO;
using System.Collections;
using System.Diagnostics;

namespace TeacherMachine
{
    public partial class TeacherDemo : Form
    {
        private myServer myudp;

        private Thread mythread;

        private static uint packetIndex = 0;
        private static uint packetID = 0;
        public TeacherDemo()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
         private Stopwatch sw = null; //实例化一个对象

         private void TeacherDemo_Load(object sender, EventArgs e)
         {
             myudp = new myServer();

             mythread = new Thread(captureImage);
             mythread.IsBackground = true;
             mythread.Start();
             sw = new Stopwatch();
         }




        private void captureImage()
        {
            Bitmap tempMap = null;
            while (true)
            {
               
                tempMap = CaptureScreen.CaptureScreenFun(true);
                sw.Stop();
                
                if (tempMap != null)
                {
                    sw.Reset();
                    sw.Start();
                    processImage(tempMap);
                    label1.Text = "时间:" + sw.ElapsedMilliseconds.ToString() + "ms";
                }
                

                //System.Threading.Thread.Sleep(30);
            }

        }




        private void segmentation(byte[] arrayFrame)
        {

            
            int  packetTotalLen  = arrayFrame.Length;       //数据帧总长度

            uint totalBlockNum = (uint)(packetTotalLen / 1024);     //分组数量 
            uint surplusNum = (uint)(packetTotalLen % 1024);        //剩余多少字节

            int arrayLen = arrayFrame.Length + 16;          //计算分组数组长度 1024 + 4(帧头) + 4(总长度) +4(分组序号)


            byte[] packetBuf = new byte[1024 + 16];
            byte[] sPacketBuf = new byte[surplusNum + 16];

            byte[] tempPacketIdBuf;
            byte[] tempPacketTotalLenBuf;
            byte[] tempPakcetIndexBuf;

 

            packetBuf[0] = 0xfe;
            packetBuf[1] = 0xfe;
            packetBuf[2] = 0x7e;
            packetBuf[3] = 0x7e;

            sPacketBuf[0] = 0xfe;
            sPacketBuf[1] = 0xfe;
            sPacketBuf[2] = 0x7e;
            sPacketBuf[3] = 0x7e;

            tempPacketIdBuf = System.BitConverter.GetBytes(packetID);
            tempPacketTotalLenBuf = System.BitConverter.GetBytes(packetTotalLen);

            for (int i = 0; i < 4; i++)
            {
                packetBuf[4 + i] = tempPacketIdBuf[i];
                packetBuf[8 + i] = tempPacketTotalLenBuf[i];
                sPacketBuf[4 + i] = tempPacketIdBuf[i];
                sPacketBuf[8 + i] = tempPacketTotalLenBuf[i];
            }


            for (int temp = 0; temp < totalBlockNum; temp++)
            {
                tempPakcetIndexBuf = System.BitConverter.GetBytes(packetIndex);

                for (int i = 0; i < 4; i++)
                {
                    packetBuf[12 + i] = tempPakcetIndexBuf[i];

                }


                for (int i = 0; i < 1024; i++)
                {
                    packetBuf[16 + i] = arrayFrame[temp * 1024 + i];
                }


                //clientApp.processRecvData(packetBuf); ;
                myudp.mySend(packetBuf);
                packetIndex++;
                
            }

            tempPakcetIndexBuf = System.BitConverter.GetBytes(packetIndex);

            for (int i = 0; i < 4; i++)
                sPacketBuf[12 + i] = tempPakcetIndexBuf[i];

            for (int i = 0; i < surplusNum; i++)
            {
                sPacketBuf[16 + i] = arrayFrame[totalBlockNum * 1024 + i];

            }
            myudp.mySend(sPacketBuf);
            

            packetIndex = 0;
            packetID++;

            
        }



        private int mTestNum = 0;


        private void processImage(Bitmap map)
        {
            //sw.Reset();
            //sw.Start();
            mTestNum++;
            MemoryStream imgStream = new MemoryStream();
            byte[] arrayImg;
                        
            ImageCodecInfo jgpEncoder = GetEncoder(ImageFormat.Jpeg);
            System.Drawing.Imaging.Encoder myEncoder = System.Drawing.Imaging.Encoder.Quality;

            EncoderParameters myEncoderParameters = new EncoderParameters(1);
            EncoderParameter myEncoderParameter = new EncoderParameter(myEncoder, 70L);     //调节压缩比
            myEncoderParameters.Param[0] = myEncoderParameter;
            
            map.Save(imgStream, jgpEncoder, myEncoderParameters);

            arrayImg = imgStream.ToArray();
            //sw.Stop();
            //label1.Text = "时间:" + sw.ElapsedMilliseconds.ToString() + "ms";
            segmentation(arrayImg);

        }



        private ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = mTestNum.ToString();
            mTestNum = 0;
        }




    }
}
