﻿namespace TeacherMachine
{
    partial class TCPMonitor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showScreen = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.showScreen)).BeginInit();
            this.SuspendLayout();
            // 
            // showScreen
            // 
            this.showScreen.Location = new System.Drawing.Point(5, 13);
            this.showScreen.Margin = new System.Windows.Forms.Padding(4);
            this.showScreen.Name = "showScreen";
            this.showScreen.Size = new System.Drawing.Size(1315, 1019);
            this.showScreen.TabIndex = 3;
            this.showScreen.TabStop = false;
            // 
            // TCPMonitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1322, 1045);
            this.Controls.Add(this.showScreen);
            this.Name = "TCPMonitor";
            this.Text = "TCPMonitor";
            this.Load += new System.EventHandler(this.TCPMonitor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.showScreen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox showScreen;

    }
}