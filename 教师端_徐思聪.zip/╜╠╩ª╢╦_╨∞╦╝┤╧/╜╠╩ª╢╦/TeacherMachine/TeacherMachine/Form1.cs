﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Net.NetworkInformation;
using System.IO;

namespace TeacherMachine
{
    public partial class Form1 : Form
    {
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPEndPoint iep1;
        IPEndPoint iep2;
        EndPoint ep;
        string str;
        int length;
        bool ispe = false;       //是否允许监控窗口打开
        string getData;
        byte[] getBytes;
        UdpClient receiver = new UdpClient(10000);
        IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Any, 10001);
        StreamWriter sw;
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            iep1 = new IPEndPoint(IPAddress.Parse("172.16.202.189"), 8000);
            socket.Bind(iep1);
            ep = (EndPoint)iep1;
            sw = new StreamWriter(System.Environment.CurrentDirectory + @"\text\1.txt", true);
            Thread thread = new Thread(new ThreadStart(rcv));//建立接受线程
            thread.IsBackground = true;//线程后台运行
            thread.Start();
        }

        private void rcv()
        {
            while (true)
            {
                getBytes = new byte[1024];
                socket.ReceiveFrom(getBytes, ref ep);//获得接收数据和学生端IP地址
                getData = System.Text.Encoding.Unicode.GetString(getBytes);
                if (getData.Substring(0,4) == "1001")
                {
                    length = ep.ToString().IndexOf(":");//获得ip长度，除去端口号
                    foreach (Control control in this.Controls)//遍历label控件
                    {
                        if (control is Label && control.Tag != null && control.Tag.ToString() == ep.ToString().Substring(0, length))
                        {
                            (control as Label).Text = getData.Substring(4,getData.Length-4);//将label内容修改为接收到的学生姓名
                            (control as Label).ForeColor = Color.Green;//字体颜色变绿
                        }
                    }
                }
                else if (getData.Substring(0, 4) == "1002")
                {
                    DateTime DT = System.DateTime.Now;
                    string dt = System.DateTime.Now.ToString();
                    byte[] getByte = receiver.Receive(ref ipEndPoint);
                    string getString = System.Text.Encoding.Unicode.GetString(getByte);
                    MessageBox.Show(getString);
                    sw.WriteLine(getString);
                    sw.WriteLine(dt);
                    sw.Flush();
                }
                else if (getData.Substring(0, 4) == "1003")
                {
                    length = ep.ToString().IndexOf(":");
                    foreach (Control control in this.Controls)//遍历控件
                    {
                        if (control is PictureBox && control.Tag != null)//选取控件位PictureBox,且控件tag不为空的控件
                        {
                            PictureBox pb = (PictureBox)control;//将控件实例化成PictureBox
                            if (pb.Tag.ToString() == ep.ToString().Substring(0, length))//判断发送方的ip地址所对应的PictureBox
                            {
                                if (getData.Substring(4, getData.Length-4).Contains("举手"))
                                    pb.Image = Image.FromFile(System.Environment.CurrentDirectory + @"\image\redhand.png");
                                else if (getData.Substring(4, getData.Length-4).Contains("取消"))
                                    pb.Image = Image.FromFile(System.Environment.CurrentDirectory + @"\image\QQ截图20180515225436.png");
                            }
                        }
                    }
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            iep2 = new IPEndPoint(IPAddress.Broadcast, 8001);//广播iep
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);//向所有学生机广播
            //iep2= new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            string calltheroll = "0006";//指令0006
            byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(calltheroll);
            socket.SendTo(sendBytes, iep2);//将指令发送给学生机            
        }

        private void StartListener1()
        {
            try
            {
                iep2 = new IPEndPoint(IPAddress.Parse(str), 8001);
                string sendString = "0001";
                byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
                socket.SendTo(sendBytes, iep2);           //像选中的学生机发送远程关机指令0001
            }
            catch (Exception err)
            {
                MessageBox.Show("与学生机连接错误!server" + err.Message);

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                str = pictureBox1.Tag.ToString();
            }
            else if (checkBox2.Checked == true)
            {
                str = pictureBox2.Tag.ToString();
            }
            else if (checkBox3.Checked == true)
            {
                str = pictureBox3.Tag.ToString();
            }
            else if (checkBox4.Checked == true)
            {
                str = pictureBox4.Tag.ToString();
            }
            else if (checkBox5.Checked == true)
            {
                str = pictureBox5.Tag.ToString();
            }
            else if (checkBox6.Checked == true)
            {
                str = pictureBox6.Tag.ToString();
            }
            else if (checkBox7.Checked == true)
            {
                str = pictureBox7.Tag.ToString();
            }
            else if (checkBox8.Checked == true)
            {
                str = pictureBox8.Tag.ToString();
            }
            else if (checkBox9.Checked == true)
            {
                str = pictureBox9.Tag.ToString();
            }
            else if (checkBox10.Checked == true)
            {
                str = pictureBox10.Tag.ToString();
            }
            else if (checkBox11.Checked == true)
            {
                str = pictureBox11.Tag.ToString();
            }
            else if (checkBox12.Checked == true)
            {
                str = pictureBox12.Tag.ToString();
            }
            else if (checkBox13.Checked == true)
            {
                str = pictureBox13.Tag.ToString();
            }
            else if (checkBox14.Checked == true)
            {
                str = pictureBox14.Tag.ToString();
            }
            else if (checkBox15.Checked == true)
            {
                str = pictureBox15.Tag.ToString();
            }
            else if (checkBox16.Checked == true)
            {
                str = pictureBox16.Tag.ToString();
            }
            else if (checkBox17.Checked == true)
            {
                str = pictureBox17.Tag.ToString();
            }
            else if (checkBox18.Checked == true)
            {
                str = pictureBox18.Tag.ToString();
            }
            else if (checkBox19.Checked == true)
            {
                str = pictureBox19.Tag.ToString();
            }
            else if (checkBox20.Checked == true)
            {
                str = pictureBox20.Tag.ToString();
            }


            if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == false && checkBox4.Checked == false && checkBox5.Checked == false && checkBox6.Checked == false && checkBox7.Checked == false && checkBox8.Checked == false && checkBox9.Checked == false && checkBox10.Checked == false && checkBox11.Checked == false && checkBox12.Checked == false && checkBox13.Checked == false && checkBox14.Checked == false && checkBox15.Checked == false && checkBox16.Checked == false && checkBox17.Checked == false && checkBox18.Checked == false && checkBox19.Checked == false && checkBox20.Checked)
                MessageBox.Show("请选择一个学生机！");
            StartListener1();
            
        }

        private void StartListener2()
        {
            try
            {
                iep2 = new IPEndPoint(IPAddress.Parse(str), 8001);
                string sendString = "0003";
                byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
                socket.SendTo(sendBytes,iep2);           //向选中的学生机发送屏幕监控指令0003
            }
            catch (Exception err)
            {
                MessageBox.Show("与学生机连接错误!server" + err.Message);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ispe = false;
            if (checkBox1.Checked == true)
            {
                str = pictureBox1.Tag.ToString();
            }
            else if (checkBox2.Checked == true)
            {
                str = pictureBox2.Tag.ToString();
            }
            else if (checkBox3.Checked == true)
            {
                str = pictureBox3.Tag.ToString();
            }
            else if (checkBox4.Checked == true)
            {
                str = pictureBox4.Tag.ToString();
            }
            else if (checkBox5.Checked == true)
            {
                str = pictureBox5.Tag.ToString();
            }
            else if (checkBox6.Checked == true)
            {
                str = pictureBox6.Tag.ToString();
            }
            else if (checkBox7.Checked == true)
            {
                str = pictureBox7.Tag.ToString();
            }
            else if (checkBox8.Checked == true)
            {
                str = pictureBox8.Tag.ToString();
            }
            else if (checkBox9.Checked == true)
            {
                str = pictureBox9.Tag.ToString();
            }
            else if (checkBox10.Checked == true)
            {
                str = pictureBox10.Tag.ToString();
            }
            else if (checkBox11.Checked == true)
            {
                str = pictureBox11.Tag.ToString();
            }
            else if (checkBox12.Checked == true)
            {
                str = pictureBox12.Tag.ToString();
            }
            else if (checkBox13.Checked == true)
            {
                str = pictureBox13.Tag.ToString();
            }
            else if (checkBox14.Checked == true)
            {
                str = pictureBox14.Tag.ToString();
            }
            else if (checkBox15.Checked == true)
            {
                str = pictureBox15.Tag.ToString();
            }
            else if (checkBox16.Checked == true)
            {
                str = pictureBox16.Tag.ToString();
            }
            else if (checkBox17.Checked == true)
            {
                str = pictureBox17.Tag.ToString();
            }
            else if (checkBox18.Checked == true)
            {
                str = pictureBox18.Tag.ToString();
            }
            else if (checkBox19.Checked == true)
            {
                str = pictureBox19.Tag.ToString();
            }
            else if (checkBox20.Checked == true)
            {
                str = pictureBox20.Tag.ToString();
            }


            if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == false && checkBox4.Checked == false && checkBox5.Checked == false && checkBox6.Checked == false && checkBox7.Checked == false && checkBox8.Checked == false && checkBox9.Checked == false && checkBox10.Checked == false && checkBox11.Checked == false && checkBox12.Checked == false && checkBox13.Checked == false && checkBox14.Checked == false && checkBox15.Checked == false && checkBox16.Checked == false && checkBox17.Checked == false && checkBox18.Checked == false && checkBox19.Checked == false && checkBox20.Checked)
                MessageBox.Show("请选择一个学生机进行监控！");
            else
                ispe = true;
            StartListener2();
            if (ispe == true)
            {
                TCPMonitor monitor = new TCPMonitor();
                monitor.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ThreadsPing("172.16.202.20", 20);
        }

        private void MyPing(Object IP)
        {
            Ping p = new Ping();
            PingReply reply = p.Send((String)IP, 100);
            if (reply.Status == IPStatus.Success)
            {
                foreach (Control control in this.Controls)
                {
                    if (control is PictureBox && control.Tag.ToString() == IP.ToString())
                        (control as PictureBox).Image = Image.FromFile(System.Environment.CurrentDirectory + @"\image\QQ图片20180612113356.png");
                }
            }
            else
            {
                foreach (Control control in this.Controls)
                {
                    if (control is PictureBox && control.Tag.ToString() == IP.ToString())
                        (control as PictureBox).Image = Image.FromFile(System.Environment.CurrentDirectory + @"\image\QQ截图20180515225436.png");
                }
            }
        }
        private void ThreadsPing(String IP, int n)
        {
            Byte[] IPByte = IPAddress.Parse(IP).GetAddressBytes();
            Thread[] th = new Thread[n];
            for (int i = 0; i < n; i++)
            {
                th[i] = new Thread(new ParameterizedThreadStart(MyPing));
                String who;
                who = String.Format("{0}.{1}.{2}.{3}", IPByte[0], IPByte[1], IPByte[2], IPByte[3] + i);
                th[i].Start(who);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            iep2 = new IPEndPoint(IPAddress.Broadcast, 8001);//广播iep
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);//向所有学生机广播
            //iep2= new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            string calltheroll = "0005";//指令0005
            byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(calltheroll);
            socket.SendTo(sendBytes, iep2);//将指令发送给学生机
            TeacherDemo demo = new TeacherDemo();
            demo.Show();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (File.Exists(System.Environment.CurrentDirectory + @"\text\1.txt"))
            {
                sw.Close();
                File.Delete(System.Environment.CurrentDirectory + @"\text\1.txt");
            }
        }

    }
}
