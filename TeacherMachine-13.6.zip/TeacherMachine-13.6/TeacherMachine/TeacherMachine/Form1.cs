﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace TeacherMachine
{
    public partial class Form1 : Form
    {
        int seq=0;     //教师端选中的学生机序号
        string str;
        int sum=0;    //记录选中的学生机的数量
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                seq = 1;
                str = "172.20.10.11";
            }
            else if (checkBox2.Checked == true)
            {
                seq = 2;
                str = "172.20.10.2";
            }
            else if (checkBox3.Checked == true)
            {
                seq = 3;
                str = "172.18.187.36";
            }
            else if (checkBox4.Checked == true)
            {
                seq = 4;
                str = "172.18.187.36";
            }
            else if (checkBox5.Checked == true)
            {
                seq = 5;
                str = "172.18.187.36";
            }
            else if (checkBox6.Checked == true)
            {
                seq = 6;
                str = "172.18.187.36";
            }
            else if (checkBox7.Checked == true)
            {
                seq = 7;
                str = "172.18.187.36";
            }
            else if (checkBox8.Checked == true)
            {
                seq = 8;
                str = "172.18.187.36";
            }
            else if (checkBox9.Checked == true)
            {
                seq = 9;
                str = "172.18.187.36";
            }
            else if (checkBox10.Checked == true)
            {
                seq = 10;
                str = "172.18.187.36";
            }
            else if (checkBox11.Checked == true)
            {
                seq = 11;
                str = "172.18.187.36";
            }
            else if (checkBox12.Checked == true)
            {
                seq = 12;
                str = "172.18.187.36";
            }
            else if (checkBox13.Checked == true)
            {
                seq = 13;
                str = "172.18.187.36";
            }
            else if (checkBox14.Checked == true)
            {
                seq = 14;
                str = "172.18.187.36";
            }
            else if (checkBox15.Checked == true)
            {
                seq = 15;
                str = "172.18.187.36";
            }
            else if (checkBox16.Checked == true)
            {
                seq = 16;
                str = "172.18.187.36";
            }
            else if (checkBox17.Checked == true)
            {
                seq = 17;
                str = "172.18.187.36";
            }
            else if (checkBox18.Checked == true)
            {
                seq = 18;
                str = "172.18.187.36";
            }
            else if (checkBox19.Checked == true)
            {
                seq = 19;
                str = "172.18.187.36";
            }
            else if (checkBox20.Checked == true)
            {
                seq = 20;
                str = "172.18.187.36";
            }


            if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == false && checkBox4.Checked == false && checkBox5.Checked == false && checkBox6.Checked == false && checkBox7.Checked == false && checkBox8.Checked == false && checkBox9.Checked == false && checkBox10.Checked == false && checkBox11.Checked == false && checkBox12.Checked == false && checkBox13.Checked == false && checkBox14.Checked == false && checkBox15.Checked == false && checkBox16.Checked == false && checkBox17.Checked == false && checkBox18.Checked == false && checkBox19.Checked == false&&checkBox20.Checked)
                MessageBox.Show("请选择一个学生机进行监控！");

            if (sum > 1)
                MessageBox.Show("至多只能选择一个学生机进行监控");


            StartListener();
            TCPMonitor monitor =new TCPMonitor(seq);
            monitor.Show();
        }
        private  void StartListener()
        {
            UdpClient udpServer;
            IPEndPoint ipEndPoint;
            udpServer = new UdpClient(12345);
            ipEndPoint = new IPEndPoint(IPAddress.Parse(str), 23456);              //选中学生机地址


            try
            {

                string sendString = "0001";
                byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
                udpServer.Send(sendBytes, sendBytes.Length, ipEndPoint);           //向选中的学生机发送屏幕监控指令0001
                // MessageBox.Show(str);
                udpServer.Close();

            }
            catch (Exception err)
            {
                MessageBox.Show("与学生机连接错误!server" + err.Message);

            }
          

        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            //sum++;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox10.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox12.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox20.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox19.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox18.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox17.Checked == true)
                sum++;
            else
                sum--;
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.Checked == true)
                sum++;
            else
                sum--;
        }





    }
}
