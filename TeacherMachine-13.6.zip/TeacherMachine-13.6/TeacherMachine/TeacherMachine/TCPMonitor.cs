﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace TeacherMachine
{
    public partial class TCPMonitor : Form
    {
        int SEQ;            //教师选中的学生机对应序号
        string str="";         //学生机地址字符串表示
        int porti=0;
        bool isclose=false;
        private TcpListener tcp = null;
        private Socket socket = null;
        private NetworkStream ns = null;
        private StreamReader sr = null;
        private StreamWriter sw = null;
        private Thread tcpThread = null;
        

        public TCPMonitor(int seq)
        {
            SEQ = seq;         //教师选中的学生机对应序号
            InitializeComponent();
           // MessageBox.Show(SEQ.ToString());
        }
        public void getRemote()
        {
            
            switch(SEQ){
                case 1: str = "172.20.10.11"; break;
                case 2: str = "172.20.10.2"; break;
                default: str = "172.18.138.32"; break;
            }

            IPAddress ip = IPAddress.Parse("172.20.10.2");
            tcp = new TcpListener(ip, 8080);
            
             try
            {
              tcp.Start();
              socket = tcp.AcceptSocket();  
              ns = new NetworkStream(socket);
              sr = new StreamReader(ns);
              sw = new StreamWriter(ns);
              Thread t1 = new Thread(reciveMsg);
              t1.Start(socket);//开启线程接收消息

              //if (socket.Connected)
              //{
              //    try
              //    {
              //        while (true)
              //        {

              //            byte[] b = new byte[1024 * 256];   //设置接收的大小 
              //            int i = this.socket.Receive(b);//接收 
              //            //把byte[]转化成内存流,在把内存流转化成Image, 
              //            System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
              //            showScreen.Image = myimage; //显示 
              //        }

              //    }
              //    catch (Exception ex)
              //    {
              //        this.tcp.Stop();
              //        MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
              //    }
              //    porti++;
              //}
              //if (isclose == true)
              //{
              //    try
              //    {
              //        this.tcp.Stop();
              //        isclose = false;
              //    }
              //    catch (Exception ex)
              //    {
              //        MessageBox.Show(ex.Message);
              //    }
              //}
              
            }
            catch (Exception err)
            {
                
                MessageBox.Show("与学生机连接错误!StuClient" + err.Message);

            }
         
        }
        private void reciveMsg(object obj)
        {
            if (socket.Connected)
            {
                try
                {
                    while (true)
                    {

                        byte[] b = new byte[1024 * 256];   //设置接收的大小 
                        int i = this.socket.Receive(b);//接收 
                        //把byte[]转化成内存流,在把内存流转化成Image, 
                        System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
                        showScreen.Image = myimage; //显示 
                    }

                }
                catch (Exception ex)
                {
                    this.tcp.Stop();
                    MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
                }
            
            }
            //if (isclose == true)
            //{
            //    try
            //    {
            //        this.tcp.Stop();
            //        isclose = false;
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //}
        }


        private void TCPMonitor_Load(object sender, EventArgs e)
        {
            getRemote();
            //tcpThread = new Thread(new ThreadStart(getRemote));
            //tcpThread.Start();
        }

        private void TCPMonitor_FormClosing(object sender, FormClosingEventArgs e)
        {
            
            //socket.Close();
           // isclose = true;
           // this.socket.Close();
           



            //UdpClient udpServer;
            //IPEndPoint ipEndPoint;
            //udpServer = new UdpClient(12345);
            //ipEndPoint = new IPEndPoint(IPAddress.Parse(str), 23456);              //选中学生机地址


            //try
            //{

            //    string sendString = "0000";
            //    byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
            //    udpServer.Send(sendBytes, sendBytes.Length, ipEndPoint);           //向选中的学生机发送屏幕监控指令0001
            //    // MessageBox.Show(str);
            //    udpServer.Close();

            //}
            //catch (Exception err)
            //{
            //    MessageBox.Show("与学生机连接错误!server" + err.Message);

            //}
           
        }

       
    
              
        
      

    }
}
