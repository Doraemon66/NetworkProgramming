﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace StuClient
{
    public partial class CallTheRoll : Form
    {
        Socket socket;
        IPEndPoint iep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);//教师机iep
        public CallTheRoll(Socket socket)
        {
            InitializeComponent();
            this.socket = socket;//取socket
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(textBox1.Text);
            socket.SendTo(sendBytes, iep);//向教师机发送textBox1中的内容
            MessageBox.Show("签到成功！");
            this.Close();
        }
    }
}
