﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace StuClient
{
    public partial class Form1 : Form
    {
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPEndPoint iep;
        EndPoint ep;
        Thread thread;

        public Form1()
        {
            InitializeComponent();
            IPAddress iphost = IPAddress.Parse("127.0.0.1");
            iep = new IPEndPoint(iphost, 8000);
            ep = (EndPoint)iep;
            socket.Bind(iep);
            this.CenterToScreen();
            this.BackgroundImage = Image.FromFile(System.Environment.CurrentDirectory + @"\images\红蜘蛛.jpg");
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            IPHostEntry localhost = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ipadd in localhost.AddressList)
            {
                label2.Text = label2.Text+ipadd.ToString()+"\n";
            }
            this.ShowInTaskbar = false;
            this.Hide();
            thread = new Thread(new ThreadStart(rcv));//建立接受线程
            thread.IsBackground = true;//线程后台运行
            thread.Start();
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.ShowInTaskbar = false;
                //this.StuclientIcon.Icon = this.Icon;
                this.Hide();
            }
        }

        private void StuclientIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Visible = true;
                this.Activate();
                this.WindowState = FormWindowState.Normal;
            } 
        }

        private void StuclientIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                MyMenu.Show();
            } 
        }

        private void 退出_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 举手_Click(object sender, EventArgs e)
        {
            if (MyMenu.Items[0].ToString() == "举手")
            {
                //MessageBox.Show(System.Environment.CurrentDirectory);
                this.StuclientIcon.Icon = new Icon(System.Environment.CurrentDirectory+@"\images\举手.ico");
                MyMenu.Items[0].Text = "取消举手";
            }
            else
            {
                this.StuclientIcon.Icon = new Icon(System.Environment.CurrentDirectory + @"\images\StuClient.ico");
                MyMenu.Items[0].Text = "举手";
            }
        }

        private void 联机讨论_Click(object sender, EventArgs e)
        {
            Form check = Application.OpenForms["communication"];
            if ((check==null)||(check.IsDisposed))
            {
                communication comm = new communication();
                comm.Show();
            }
            else
            {
                check.Activate();
            }
        }

        private void rcv()
        {
            byte[] getBytes = new byte[1024];
            while (true)
            {
                socket.ReceiveFrom(getBytes, ref ep);//接收指令数据
                string getData = System.Text.Encoding.Unicode.GetString(getBytes);//获得指令字符
                string command = getData.Substring(0,4);//接收教师机指令
                switch (command)
                {
                    case "0005":
                        new CallTheRoll(socket).ShowDialog();//打开签到窗口
                        break;
                }
            }
        }
    }
}
