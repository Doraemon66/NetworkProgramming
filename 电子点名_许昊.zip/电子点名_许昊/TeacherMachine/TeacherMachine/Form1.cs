﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace TeacherMachine
{
    public partial class Form1 : Form
    {
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        IPEndPoint iep1;
        IPEndPoint iep2;
        EndPoint ep;
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            iep1 = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);
            socket.Bind(iep1);
            ep = (EndPoint)iep1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //iep1 = new IPEndPoint(IPAddress.Broadcast, 8888);//广播iep
            //socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);//向所有学生机广播
            iep2= new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            string calltheroll = "0005";//指令0005
            byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(calltheroll);
            socket.SendTo(sendBytes, iep2);//将指令发送给学生机
            //socket.Close();
            Thread thread = new Thread(new ThreadStart(rcv));//建立接受线程
            thread.IsBackground = true;//线程后台运行
            thread.Start();
        }

        private void rcv()
        {
            while (true)
            {
                byte[] getBytes = new byte[1024];
                socket.ReceiveFrom(getBytes, ref ep);
                int length = ep.ToString().IndexOf(":");//获得学生端IP地址
                string getData = System.Text.Encoding.Unicode.GetString(getBytes);
                foreach (Control control in this.Controls)//遍历label控件
                {
                    if (control is Label && control.Tag != null && control.Tag.ToString().Equals(ep.ToString().Substring(0, length)))
                    {
                        control.Text = getData;//将label内容修改为接收到的学生姓名
                        control.ForeColor = Color.Green;//字体颜色变绿
                    }
                }
            }
        }
    }
}
