﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using System.Data;
using System.Drawing;
using System.IO;
using System.Collections;

namespace StuClient
{
    class myclient
    {
        private static IPAddress GroupAddress = IPAddress.Parse("224.5.6.7");
        private static int GroupPort = 11002;
        private UdpClient myUdpClient;
        private IPEndPoint GroupEP;

        private static uint packetId = 12345;
        private FullFlag full = null;
        private byte[] pBuf = null;             //接收到是分组数据存放在该数据中。

        private static uint totalTemp = 0;

        private Socket s;
        private IPEndPoint iep;
        private EndPoint ep;

        public myclient()
        {

            myUdpClient = new UdpClient(11002);
            myUdpClient.JoinMulticastGroup(GroupAddress);
            GroupEP = new IPEndPoint(GroupAddress, GroupPort);
            myUdpClient.EnableBroadcast = true;

            full = new FullFlag();
            full.clear();
            /*
            full = new FullFlag();
            full.clear();

            Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPEndPoint iep = new IPEndPoint(IPAddress.Any, 11001);
            EndPoint ep = (EndPoint)iep;
            s.Bind(iep);
            s.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(IPAddress.Parse("224.5.6.7")));

            */


        }


        public byte[] ret()
        {
            return pBuf;
        }



        private void createArray(int len)
        {
            pBuf = new byte[len];
        }



        public bool recvData(byte[] recvBuf, int len, int blockLen, uint pIndex)
        {
            int a = 0;
            int b = 0;

            if (full.isEmpty())
            {
                createArray(len);
            }

            full.set(pIndex);

            for (int i = 0; i < blockLen; i++)
            {
                a = (int)(pIndex * 1024 + i);
                //b = 16 + i;
                pBuf[a] = recvBuf[i];
            }

            if (full.isFull((uint)(len / 1024)))
            {
                full.clear();
                return true;
            }

            return false;


        }




        public byte[] processRecvData()
        {
            byte[] recvBuf;
            byte[] headBuf = new byte[4];
            byte[] packetIdBuf = new byte[4];
            byte[] packetTotalBuf = new byte[4];
            byte[] packetIndexBuf = new byte[4];
            byte[] processBuf = null;

            uint blockNum = 0;
            int totalNum = 1;
            uint tempId;
            uint index = 0;
            uint tempIndex = 0;
            uint diubao = 0;
            Bitmap imgMap;

            //while (true)
            {

                recvBuf = myUdpClient.Receive(ref GroupEP);
                if (recvBuf == null)
                {
                    return null;// continue;
                }

                if (recvBuf.Length < 16)
                {
                    return null;//continue;
                }


                if ((recvBuf[0] != 0xfe) || (recvBuf[1] != 0xfe) || (recvBuf[2] != 0x7e) || (recvBuf[3] != 0x7e))
                {
                    return null;//continue;
                }

                for (int i = 0; i < 4; i++)
                {
                    packetIdBuf[i] = recvBuf[4 + i];
                }


                for (int i = 0; i < 4; i++)
                {
                    packetTotalBuf[i] = recvBuf[8 + i];
                }

                totalNum = System.BitConverter.ToInt32(packetTotalBuf, 0);

                blockNum = (uint)(totalNum / 1024);


                tempId = System.BitConverter.ToUInt32(packetIdBuf, 0);
                if (tempId != packetId)                                 //id不一样表示来了新数据。
                {
                    packetId = tempId;
                    full.clear();


                }


                for (int i = 0; i < 4; i++)
                {
                    packetIndexBuf[i] = recvBuf[12 + i];
                }

                index = System.BitConverter.ToUInt32(packetIndexBuf, 0);

                processBuf = new byte[recvBuf.Length - 16];

                if (processBuf == null)
                {
                    return null;
                }

                for (int i = 16; i < recvBuf.Length; i++)
                {
                    processBuf[i - 16] = recvBuf[i];
                }

                if (recvData(processBuf, (int)totalNum, (int)(recvBuf.Length - 16), (uint)index))
                {
                    return pBuf;
                }

                /*

                    if ((index + 10) > blockNum)
                    {
                        if( full.isFull((uint)totalNum) )
                        {
                            MemoryStream imgStream = new MemoryStream(pBuf);
                            imgMap = (Bitmap)Image.FromStream(imgStream);

                            return imgMap;
                        }
                    }
                */

            }

            return null;

        }


    }
}
