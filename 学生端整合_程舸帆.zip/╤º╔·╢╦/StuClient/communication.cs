﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace StuClient
{
    public partial class communication : Form
    {
        Socket socket;//组播使用的socket
        IPEndPoint multiIPEnd;//组播地址
        Thread thread;//聊天创建的线程
        int zuboflag = 0;//退出方式控制标志位，不需要改
        public communication()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;//加这句话可以实现控件跨线程操作
        }

        private void button1_Click(object sender, EventArgs e)
        {
            communication_FormClosing(sender, e);
            zuboflag = 1;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!sendTextBox.Text.Equals(""))//非空发送
            {
                SendMessage(socket);
                sendTextBox.Text = "";
            }
        }
        private void zuBo()
        {
            int PortNum = 9999;
            IPAddress address = IPAddress.Parse("224.0.0.2");//定义组播地址
            multiIPEnd = new IPEndPoint(address, PortNum);//定义组播地址

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);//创建UDP套接字

            IPEndPoint myhost = new IPEndPoint(IPAddress.Any, PortNum);//我的地址
            socket.Bind(myhost);//绑定IP地址
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(address));
            //socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 32);

            thread = new Thread(new ParameterizedThreadStart(zuBoReceiveMessage));
            thread.Start(socket);//启动线程

            byte[] bytes = System.Text.Encoding.Unicode.GetBytes("#");//发送#代表加入组播队列
            socket.SendTo(bytes, SocketFlags.None, multiIPEnd);
        }

        //组播接收信息
        private void zuBoReceiveMessage(Object socket1)
        {
            Socket socket = (Socket)socket1;
            EndPoint ep = (EndPoint)multiIPEnd;
            string str;
            byte[] data = new byte[1024];
            int length;
            while (true)
            {
                length = socket.ReceiveFrom(data, ref ep);
                string epAddress = ep.ToString();
                epAddress = epAddress.Substring(0, epAddress.LastIndexOf(":"));
                str = System.Text.Encoding.Unicode.GetString(data, 0, length);
                switch (str[0])
                {
                    case '#'://成员加入
                        this.receiveTextBox.AppendText("[" + epAddress + "]进入。\n");
                        string str1 = "&:" + epAddress;
                        for (int i = 0; i < this.listBox1.Items.Count; i++)
                        {
                            str1 += ":" + this.listBox1.Items[i].ToString();
                        }
                        byte[] users = System.Text.Encoding.Unicode.GetBytes(str1);
                        socket.SendTo(users, SocketFlags.None, multiIPEnd);
                        break;
                    case '@'://退出

                        this.receiveTextBox.AppendText("[" + epAddress + "]退出。\n");
                        this.listBox1.Items.Remove(epAddress);
                        break;
                    case '&'://小组成员名单
                        string[] strArray = str.Split(':');
                        for (int i = 1; i < strArray.Length; i++)
                        {
                            bool isExist = false;
                            for (int j = 0; j < this.listBox1.Items.Count; j++)
                            {
                                if (strArray[i] == this.listBox1.Items[j].ToString())
                                {
                                    isExist = true;
                                    break;

                                }
                            }

                            if (isExist == false)
                            {
                                this.listBox1.Items.Add(strArray[i]);
                            }
                        }
                        break;
                    case '!'://发言内容
                        this.receiveTextBox.AppendText("[" + epAddress + "]说：");
                        this.receiveTextBox.AppendText(str.Substring(1) + "\n");
                        break;
                }
            }

        }

        //发送信息
        private void SendMessage(Socket socket)
        {
            byte[] data = new byte[1024];
            data = System.Text.Encoding.Unicode.GetBytes("!" + sendTextBox.Text);
            socket.SendTo(data, SocketFlags.None, multiIPEnd);
        }

        private void communication_Load(object sender, EventArgs e)
        {
            zuBo();
        }

        private void communication_FormClosing(object sender, EventArgs e)
        {
            if (zuboflag == 1) return;
            if (socket != null && socket.Connected)
            {
                byte[] data = System.Text.Encoding.Unicode.GetBytes("@");
                socket.SendTo(data, SocketFlags.None, multiIPEnd);
            }
            if (thread == null && socket == null) return;
            if (thread.IsAlive)
                thread.Abort();

            socket.Close();
            //MessageBox.Show("成功关闭");

        }

        private void communication_Load_1(object sender, EventArgs e)
        {
            zuBo();
        }
    }
}
