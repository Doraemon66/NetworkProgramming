﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace StuClient
{
    public partial class Form1 : Form
    {
        Socket handup = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);//建立发送套接字
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        //IPAddress iphost = IPAddress.Parse("127.0.0.1");
        //IPEndPoint iep= new IPEndPoint(iphost, 8000);
        private NetworkStream ns = null;
        private StreamReader sr = null;
        private StreamWriter sw = null;
        private Thread tcpThread = null;
        private TcpClient tcpclient = null;
        MemoryStream ms = null;
        UdpClient udpClient=new UdpClient(8001);
        //IPEndPoint ipEndPoint;
        bool isclose = false;
        // IPAddress iphost = IPAddress.Parse("127.0.0.1");
        bool isCon = false;
        bool isError = false;
        bool isSend = false;           //学生机是否发送屏幕信息标志位
        int porti = 0;
        //private myclient udpclient = null;
        private Thread mythread = null;
        public Form1()
        {
            InitializeComponent();
            //IPAddress iphost = IPAddress.Parse("127.0.0.1");
            //iep = new IPEndPoint(iphost, 8000);
            this.CenterToScreen();
            this.BackgroundImage = Image.FromFile(System.Environment.CurrentDirectory + @"\images\红蜘蛛.jpg");
            this.StuclientIcon.Icon = new Icon(System.Environment.CurrentDirectory + @"\images\computer.ico");
            Thread thread = new Thread(new ThreadStart(rcv));//建立接受线程
            thread.IsBackground = true;//线程后台运行
            thread.Start();
          
           
        }
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr CreateDC(
              string lpszDriver, // 驱动名称 
              string lpszDevice, // 设备名称 
              string lpszOutput, // 无用，可以设定位"NULL" 
              IntPtr lpInitData // 任意的打印机数据 
            );
        [System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")]
        private static extern bool BitBlt(
        IntPtr hdcDest, //目标设备的句柄 
        int nXDest, // 目标对象的左上角的X坐标 
        int nYDest, // 目标对象的左上角的X坐标 
        int nWidth, // 目标对象的矩形的宽度 
        int nHeight, // 目标对象的矩形的长度 
        IntPtr hdcSrc, // 源设备的句柄 
        int nXSrc, // 源对象的左上角的X坐标 
        int nYSrc, // 源对象的左上角的X坐标 
        System.Int32 dwRop // 光栅的操作值 
        );
        IPAddress iphost = IPAddress.Parse("172.16.202.189");
      //  IPEndPoint iep = new IPEndPoint(iphost, 8000);
     
        private void Form1_Load(object sender, EventArgs e)
        {
            IPHostEntry localhost = Dns.GetHostEntry(Dns.GetHostName());//获取本机ip地址
            foreach (IPAddress ipadd in localhost.AddressList)
            {
                label2.Text = label2.Text + ipadd.ToString() + "\n";
            }
            this.ShowInTaskbar = false;//任务栏不显示窗体
            this.Hide();
            timer1.Enabled = false;      //定时器关
            Control.CheckForIllegalCrossThreadCalls = false;

            //udpclient = new myclient();
            mythread = new Thread(rcv);

           // mythread.IsBackground = true;
            mythread.Start();
            //IPAddress iphost = IPAddress.Parse("127.0.0.1");
            //IPEndPoint iep = new IPEndPoint(iphost, 8000);

        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)//关闭form1时，取消关闭操作，隐藏窗体，小图标运行
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.ShowInTaskbar = false;
                //this.StuclientIcon.Icon = this.Icon;
                this.Hide();
            }
        }

        private void StuclientIcon_MouseDoubleClick(object sender, MouseEventArgs e)//左键双击图标，激活并显示主界面
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Visible = true;
                this.Activate();
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void StuclientIcon_MouseClick(object sender, MouseEventArgs e)//右键单击显示图标菜单
        {
            if (e.Button == MouseButtons.Right)
            {
                MyMenu.Show();
            }
        }

        private void 退出_Click(object sender, EventArgs e)//程序退出
        {
            Application.Exit();
        }

        private void 举手_Click(object sender, EventArgs e)//点出菜单，单击举手项
        {
            IPEndPoint iep = new IPEndPoint(iphost, 8000);
            if (MyMenu.Items[0].ToString() == "举手")
            {
                //MessageBox.Show(System.Environment.CurrentDirectory);
                this.StuclientIcon.Icon = new Icon(System.Environment.CurrentDirectory + @"\images\redhand.ico");
                MyMenu.Items[0].Text = "取消举手";
                byte[] sendbytes = System.Text.Encoding.Unicode.GetBytes("1003举手");
                handup.SendTo(sendbytes, iep);
            }
            else
            {
                this.StuclientIcon.Icon = new Icon(System.Environment.CurrentDirectory + @"\images\computer.ico");
                MyMenu.Items[0].Text = "举手";
                byte[] sendbytes = System.Text.Encoding.Unicode.GetBytes("1003取消");
                handup.SendTo(sendbytes, iep);
            }
        }

        private void 联机讨论_Click(object sender, EventArgs e)
        {
            Form check = Application.OpenForms["communication"];//检查Name为communication的窗体
            if ((check == null) || (check.IsDisposed))//如果窗体为空或者已释放
            {
                communication comm = new communication();//新建communication窗体
                comm.Show();
            }
            else
            {
                check.Activate();//否则激活该窗体
            }
        }

        private void 电子签到ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IPEndPoint iep = new IPEndPoint(iphost, 8000);
            string sendString = "1002";
            //Byte[] sendBytes = UTF8Encoding.UTF8.GetBytes(sendString);
            Byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(sendString);
            udpClient.Send(sendBytes, sendBytes.Length, iep); 
            SignIn s = new SignIn();
            s.Show();
        }

        /* private void 远程关机ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
         */
        private void rcv()
        {
            IPEndPoint iep = new IPEndPoint(iphost, 8000);
            //UdpClient udpClient;
            //IPEndPoint ipEndPoint;
           // udpClient = new UdpClient(8000);
           // ipEndPoint = new IPEndPoint(new IPAddress(0), 0);
            byte[] img;
            Bitmap map;

           
            while(true)
            {


                byte[] getBytes = udpClient.Receive(ref iep);
                string getString = Encoding.Unicode.GetString(getBytes, 0, getBytes.Length);
                //MessageBox.Show(getString);
                if (getString.Substring(0, 4) == "0001")
                {
                    //MessageBox.Show("即将关机");
                    Process pro = new Process();
                    pro.StartInfo.FileName = "shutdown.exe";
                    pro.StartInfo.Arguments = "-s -t 3";//延时时间为0（马上关机）
                    pro.StartInfo.UseShellExecute = false;//不使用操作系统外壳程序启动进程
                    pro.StartInfo.CreateNoWindow = true;//不创建窗体
                    pro.StartInfo.RedirectStandardOutput = true;
                    pro.Start();
                }
                else if (getString.Substring(0, 4) == "0003")
                {
                    isSend = true;
                    timer1.Enabled = true;
                    MessageBox.Show("教师机开启屏幕监视");
                }
                else if (getString.Substring(0, 4) == "0005")
                {

                    new demo().ShowDialog();
                    /*MessageBox.Show("即将开始屏幕演示");
                    img = udpclient.processRecvData();
                    if (img != null)
                    {
                        try
                        {
                           MemoryStream imgStream = new MemoryStream(img);
                            map = (Bitmap)Image.FromStream(imgStream);

                            if (map != null)
                                pictureBox1.Image = map;
                        }
                        catch (Exception e)
                        {
                            continue;
                        }
                    }*/

                }
                else if (getString.Substring(0, 4) == "0006")
                {
                    new CallTheRoll(socket).ShowDialog();//打开签到窗口
                    break;
                }
                
             //   udpClient.Close();

            
            
        }
       }

        public void con()
        {
            try
            {

                tcpclient = new TcpClient();
                tcpclient.Connect("172.16.202.189", 8080);
                if (tcpclient.Connected)
                {
                    ns = tcpclient.GetStream();
                    sr = new StreamReader(ns);
                    sw = new StreamWriter(ns);
                    isCon = true;

                }


            }
            catch
            {
                isError = true;
                tcpclient.Close();

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!isCon)
            {
                
                con();


               if (!isError)
                {
                    timer1.Enabled = false;
                    tcpThread = new Thread(new ThreadStart(connect));
                    tcpThread.Start();

                }
                isError = false;
            }
        } 

        public void connect()
        {
            
            try
            {

                while (isSend)
                {
                    capture();
                    Thread.Sleep(1000);
                }
                isSend = false;
            }
            catch (Exception ex)
            {

                //tcpclient.Close();

                //sw.Dispose();
                //sr.Dispose();
                //ns.Dispose();
                isCon = false;
                isError = false;
                isSend = false;
                timer1.Enabled = true;

            }
        }

        public void capture()
        {
            //this.Visible = false; 
            IntPtr dc1 = CreateDC("DISPLAY", null, null, (IntPtr)null);
            //创建显示器的DC 
            Graphics g1 = Graphics.FromHdc(dc1);
            //由一个指定设备的句柄创建一个新的Graphics对象 
            System.Drawing.Image MyImage = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, g1);
            //根据屏幕大小创建一个与之相同大小的Bitmap对象 
            Graphics g2 = Graphics.FromImage(MyImage);
            //获得屏幕的句柄 
            IntPtr dc3 = g1.GetHdc();
            //获得位图的句柄 
            IntPtr dc2 = g2.GetHdc();
            //把当前屏幕捕获到位图对象中 
            BitBlt(dc2, 0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, dc3, 0, 0, 13369376);
            //把当前屏幕拷贝到位图中 
            g1.ReleaseHdc(dc3);
            //释放屏幕句柄 
            g2.ReleaseHdc(dc2);
            //释放位图句柄 
            ms = new MemoryStream();
            MyImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] b = ms.GetBuffer();
            ns.Write(b, 0, b.Length);
            ms.Flush();

        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

    }
}
