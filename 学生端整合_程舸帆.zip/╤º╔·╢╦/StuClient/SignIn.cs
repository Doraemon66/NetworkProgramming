﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace StuClient
{
    public partial class SignIn : Form
    {
        IPEndPoint iep = new IPEndPoint(IPAddress.Parse("172.16.202.189"), 10000) ;
        public SignIn()
        {
            InitializeComponent();    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Listen(); //监听
            this.Close();
        }
        private void Listen()
        {
            UdpClient udpclient;
            udpclient = new UdpClient(10001);
            try
            {
                string sendString = textBox1.Text + textBox2.Text;
                Byte[] sendBytes = System.Text.Encoding.Unicode.GetBytes(sendString);
                //byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
                udpclient.Send(sendBytes, sendBytes.Length, iep);           //向教师机发送签到信息
                // MessageBox.Show(str);
                udpclient.Close();

            }
            catch (Exception err)
            {
                MessageBox.Show("与教师机连接错误!server" + err.Message);

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();

        }

    }
}
