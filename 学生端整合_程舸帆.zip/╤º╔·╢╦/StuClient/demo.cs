﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;

namespace StuClient
{
    public partial class demo : Form
    {
        private myclient udpclient = null;
        private Thread mythread = null;
        public demo()
        {
            InitializeComponent();
        }

        private void recv()
        {
            byte[] img;
            Bitmap map;

            if (udpclient == null)
            {
                return;
            }

            while (true)
            {
                img = udpclient.processRecvData();

                if (img != null)
                {
                    try
                    {
                        MemoryStream imgStream = new MemoryStream(img);
                        map = (Bitmap)Image.FromStream(imgStream);

                        if (map != null)
                            pictureBox.Image = map;
                    }
                    catch (Exception e)
                    {
                        continue;
                    }
                }
            }

        }

        private void demo_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;

            udpclient = new myclient();
            mythread = new Thread(recv);

            mythread.IsBackground = true;
            mythread.Start();
        }
    }
}
