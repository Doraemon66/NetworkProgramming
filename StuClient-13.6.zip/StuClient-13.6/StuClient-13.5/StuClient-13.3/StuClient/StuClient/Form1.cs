﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace StuClient
{
    public partial class Form1 : Form
    {
        private NetworkStream ns = null;
        private StreamReader sr = null;
        private StreamWriter sw = null;
        private Thread tcpThread = null;
        private TcpClient tcpclient = null;
        MemoryStream ms = null;
        bool isCon = false;
        bool isError = false;
        bool isSend = false;           //学生机是否发送屏幕信息标志位
        int porti = 0;


        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();
            this.BackgroundImage = Image.FromFile(System.Environment.CurrentDirectory + @"\images\红蜘蛛.jpg");
            
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr CreateDC(
              string lpszDriver, // 驱动名称 
              string lpszDevice, // 设备名称 
              string lpszOutput, // 无用，可以设定位"NULL" 
              IntPtr lpInitData // 任意的打印机数据 
            );
        [System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")]
        private static extern bool BitBlt(
        IntPtr hdcDest, //目标设备的句柄 
        int nXDest, // 目标对象的左上角的X坐标 
        int nYDest, // 目标对象的左上角的X坐标 
        int nWidth, // 目标对象的矩形的宽度 
        int nHeight, // 目标对象的矩形的长度 
        IntPtr hdcSrc, // 源设备的句柄 
        int nXSrc, // 源对象的左上角的X坐标 
        int nYSrc, // 源对象的左上角的X坐标 
        System.Int32 dwRop // 光栅的操作值 
        );

       



        private void Form1_Load(object sender, EventArgs e)
        {
            IPHostEntry localhost = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ipadd in localhost.AddressList)
            {
                label2.Text = ipadd.ToString() + "\n";
            }
            this.ShowInTaskbar = false;
            this.Hide();
            timer1.Enabled = false;      //定时器关
            StartListener();
        }

        private void StartListener()
        {


            UdpClient udpClient;
            IPEndPoint ipEndPoint;
            udpClient = new UdpClient(23456);
            ipEndPoint = new IPEndPoint(new IPAddress(0), 0);

            try
            {
                //while (true)
                //{

                    byte[] getBytes = udpClient.Receive(ref ipEndPoint);
                    string getString = Encoding.Unicode.GetString(getBytes, 0, getBytes.Length);
                    MessageBox.Show(getString);
                    if (getString.Substring(0, 4) == "0001")
                    {
                        isSend = true;
                        timer1.Enabled = true;
                        MessageBox.Show("教师机开启屏幕监视");
                    }
                    if (getString.Substring(0, 4) == "0000")
                    {
                        isSend = false;
                        timer1.Enabled = false;
                        MessageBox.Show("教师机停止屏幕监视");
                    }
                //}

                //udpClient.Close();

            }
            catch (Exception err)
            {
                MessageBox.Show("与教师机连接错误!server" + err.Message);

            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!isCon)
            {
                con();
                if (!isError)
                {
                    timer1.Enabled = false;
                    tcpThread = new Thread(new ThreadStart(connect));
                    tcpThread.Start();

                }
                isError = false;
            } 
        }


        public void con()
        {
            try
            {
                //IPHostEntry localhost = Dns.GetHostEntry(Dns.GetHostName());
                //porti += 9000;
                //tcpclient = new TcpClient(localhost.HostName, porti);
              
                tcpclient = new TcpClient();
                tcpclient.Connect("172.20.10.2", 8080+porti);
                if (tcpclient.Connected)
                {
                    ns = tcpclient.GetStream();
                    sr = new StreamReader(ns);
                    sw = new StreamWriter(ns);
                    isCon = true;
                    porti++;
                }
             
            }
            catch
            {
                isError = true;
               
            }
        } 

        public void connect()
        {
            try
            {

                while (isSend)
                {
                    capture();
                    Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                
                sw.Dispose();
                sr.Dispose();
                ns.Dispose();
                isCon = false;
                isError = false;
                timer1.Enabled = true;
             
            }
        }

        public void capture()
        {
            //this.Visible = false; 
            IntPtr dc1 = CreateDC("DISPLAY", null, null, (IntPtr)null);
            //创建显示器的DC 
            Graphics g1 = Graphics.FromHdc(dc1);
            //由一个指定设备的句柄创建一个新的Graphics对象 
            System.Drawing.Image MyImage = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, g1);
            //根据屏幕大小创建一个与之相同大小的Bitmap对象 
            Graphics g2 = Graphics.FromImage(MyImage);
            //获得屏幕的句柄 
            IntPtr dc3 = g1.GetHdc();
            //获得位图的句柄 
            IntPtr dc2 = g2.GetHdc();
            //把当前屏幕捕获到位图对象中 
            BitBlt(dc2, 0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, dc3, 0, 0, 13369376);
            //把当前屏幕拷贝到位图中 
            g1.ReleaseHdc(dc3);
            //释放屏幕句柄 
            g2.ReleaseHdc(dc2);
            //释放位图句柄 
            ms = new MemoryStream();
            MyImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] b = ms.GetBuffer();
            ns.Write(b, 0, b.Length);
            ms.Flush();

        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.ShowInTaskbar = false;
                this.Hide();
            }
        }

        //private void StuclientIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        //{
        //    if (e.Button == MouseButtons.Left)
        //    {
        //        this.Visible = true;
        //        this.Activate();
        //        this.WindowState = FormWindowState.Normal;
        //    }
        //}

        //private void StuclientIcon_MouseClick(object sender, MouseEventArgs e)
        //{
        //    if (e.Button == MouseButtons.Right)
        //    {
        //        MyMenu.Show();
        //    }
        //}

        //private void 退出_Click(object sender, EventArgs e)
        //{
        //    Application.Exit();
        //}

        //private void 联机讨论_Click(object sender, EventArgs e)
        //{
        //    Form check = Application.OpenForms["communication"];
        //    if ((check == null) || (check.IsDisposed))
        //    {
        //        communication comm = new communication();
        //        comm.Show();
        //    }
        //    else
        //    {
        //        check.Activate();
        //    }
        //}

       


       
    }
}
