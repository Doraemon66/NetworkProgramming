﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace TeacherMachine
{
    public partial class TCPMonitor : Form
    {
        int SEQ;            //教师选中的学生机对应序号
        string str="";         //学生机地址字符串表示
        int porti=0;
        bool isclose=false;
        private TcpListener tcp = null;
        private Socket socket = null;
        private NetworkStream ns = null;
        private StreamReader sr = null;
        private StreamWriter sw = null;
        private Thread tcpThread = null;
        Thread threadwatch = null;//负责监听客户端的线程
        Socket socketwatch = null;//负责监听客户端的套接字
       //bool isclose;
        public TCPMonitor(int seq)
        {
            SEQ = seq;         //教师选中的学生机对应序号
            InitializeComponent();
           // MessageBox.Show(SEQ.ToString());
        }
        public void getRemote()
        {
            
            switch(SEQ){
                case 1: str = "172.20.10.11"; break;
                case 2: str = "172.20.10.2"; break;
                default: str = "172.18.138.32"; break;
            }
            socketwatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
             
            IPAddress ip = IPAddress.Parse("172.20.10.2");
            EndPoint ipEndPoint;
            ipEndPoint = new IPEndPoint(ip, 8080);  
            //tcp = new TcpListener(ip, 8080);
             socketwatch.Bind(ipEndPoint);
             socketwatch.Listen(50);
            
             try
            {
                
                //创建一个监听线程
                threadwatch = new Thread(watchconnecting);



                //将窗体线程设置为与后台同步，随着主线程结束而结束
                threadwatch.IsBackground = true;

                //启动线程   
                threadwatch.Start(); 

             // tcp.Start();
             // tcp.BeginAcceptSocket(new AsyncCallback(AcceptConnection),tcp);

              //socket = tcp.AcceptSocket();
              //ns = new NetworkStream(socket);
              //sr = new StreamReader(ns);
              //sw = new StreamWriter(ns);
              //Thread t1 = new Thread(reciveMsg);
              //t1.Start(socket);//开启线程接收消息

              //if (socket.Connected)
              //{
              //    try
              //    {
              //        while (true)
              //        {

              //            byte[] b = new byte[1024 * 256];   //设置接收的大小 
              //            int i = this.socket.Receive(b);//接收 
              //            //把byte[]转化成内存流,在把内存流转化成Image, 
              //            System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
              //            showScreen.Image = myimage; //显示 
              //        }

              //    }
              //    catch (Exception ex)
              //    {
              //        this.tcp.Stop();
              //        MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
              //    }
              //    porti++;
              //}
              //if (isclose == true)
              //{
              //    try
              //    {
              //        this.tcp.Stop();
              //        isclose = false;
              //    }
              //    catch (Exception ex)
              //    {
              //        MessageBox.Show(ex.Message);
              //    }
              //}

            }
            catch (Exception err)
            {
                
                MessageBox.Show("与学生机连接错误!StuClient" + err.Message);

            }
         
        }

        private void watchconnecting()
        {
            Socket connection = null;
            while (true)  //持续不断监听客户端发来的请求   
            {
                try
                {
                    connection = socketwatch.Accept();
                   // MessageBox.Show("yilianjie");
                }
                catch (Exception ex)
                {
                    
                    break;
                }

                ns = new NetworkStream(connection);
                sr = new StreamReader(ns);
                sw = new StreamWriter(ns);

                try
                {
                    while (true)
                    {

                        byte[] b = new byte[1024 * 256];   //设置接收的大小 
                        int i = connection.Receive(b);//接收 
                        //把byte[]转化成内存流,在把内存流转化成Image, 
                        System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
                        showScreen.Image = myimage; //显示 
                    }

                }
                catch (Exception ex)
                {
                    connection.Close();
                    socketwatch.Close();
                    //.Close();
                    MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
                }
                if (isclose == true)
                {
                    socketwatch.Close();
                }
                //Thread t1 = new Thread(reciveMsg);
                //t1.IsBackground = true;
                //t1.Start(connection);//开启线程接收消息

                ////创建一个通信线程    
                //ParameterizedThreadStart pts = new ParameterizedThreadStart(recv);
                //Thread thread = new Thread(pts);
                //thread.IsBackground = true;//设置为后台线程，随着主线程退出而退出   
                ////启动线程   
                //thread.Start(connection);
            }
        }

        //private void AcceptConnection(IAsyncResult iar)
        //{
        //    //还原传入的原始套接字
        //    Socket MyServer = (Socket)iar.AsyncState;
        //    //在原始套接字上调用EndAccept方法，返回新的套接字
        //    Socket service = MyServer.EndAccept(iar);
            
        //    //Socket recServer = (Socket)ar.AsyncState;
        //    //异步接收传入的连接，并创建新的Socket来处理远程主机通信
        //   // clientSocket = oldServer.EndAccept(ar);
        //  //  this.listBoxState.Items.Add("与客户" + clientSocket.RemoteEndPoint.ToString() + "建立连接。");
        //  //  byte[] message = System.Text.Encoding.Unicode.GetBytes("客户你好！");
        //  //  clientSocket.BeginSend(message, 0, message.Length, SocketFlags.None, new AsyncCallback(SendData), clientSocket);

           
        //    ns = new NetworkStream(service);
        //    sr = new StreamReader(ns);
        //    sw = new StreamWriter(ns);
        //    //Thread t1 = new Thread(reciveMsg);
        //    //t1.Start(socket);//开启线程接收消息
        //     if (service.Connected)
        //    {
        //        try
        //        {
        //            while (true)
        //            {

        //                byte[] b = new byte[1024 * 256];   //设置接收的大小 
        //                int i = service.Receive(b);//接收 
        //                //把byte[]转化成内存流,在把内存流转化成Image, 
        //                System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
        //                showScreen.Image = myimage; //显示 
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            this.tcp.Stop();
        //            MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
        //        }
            
        //    }
        //}

        //private void reciveMsg(object obj)
        //{
        //    if (connection.Connected)
        //    {
        //        try
        //        {
        //            while (true)
        //            {

        //                byte[] b = new byte[1024 * 256];   //设置接收的大小 
        //                int i = this.socket.Receive(b);//接收 
        //                //把byte[]转化成内存流,在把内存流转化成Image, 
        //                System.Drawing.Image myimage = System.Drawing.Image.FromStream(new MemoryStream(b));
        //                showScreen.Image = myimage; //显示 
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            this.tcp.Stop();
        //            MessageBox.Show("捕捉屏幕出错!server" + ex.Message);
        //        }

        //    }

        //}


        private void TCPMonitor_Load(object sender, EventArgs e)
        {
            //getRemote();
            tcpThread = new Thread(new ThreadStart(getRemote));
            tcpThread.Start();
        }

        private void TCPMonitor_FormClosing(object sender, FormClosingEventArgs e)
        {
            isclose = true;
            socketwatch.Close();
           // tcp.Stop();
            //UdpClient udpServer;
            //IPEndPoint ipEndPoint;
            //udpServer = new UdpClient(12345);
            //ipEndPoint = new IPEndPoint(IPAddress.Parse(str), 23456);              //选中学生机地址


            //try
            //{

            //    string sendString = "0000";
            //    byte[] sendBytes = Encoding.Unicode.GetBytes(sendString);
            //    udpServer.Send(sendBytes, sendBytes.Length, ipEndPoint);           //向选中的学生机发送屏幕监控指令0001
            //    // MessageBox.Show(str);
            //    udpServer.Close();

            //}
            //catch (Exception err)
            //{
            //    MessageBox.Show("与学生机连接错误!server" + err.Message);

            //}
           
        }

    

       
    
              
        
      

    }
}
