﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace TeacherMachine
{
    public partial class TCPMonitor : Form
    {
        private TcpListener tcp = null;
        private Socket socket = null;
        private NetworkStream ns = null;
        private StreamReader sr = null;
        private StreamWriter sw = null;
        private Thread tcpThread = null;

        public TCPMonitor()
        {
            InitializeComponent();
        }
        public void getRemote()
        {
            IPAddress ip = IPAddress.Parse("172.16.202.189");
            tcp = new TcpListener(ip, 8080);
            tcp.Start();
            socket = tcp.AcceptSocket();
            ns = new NetworkStream(socket);
            sr = new StreamReader(ns);
            sw = new StreamWriter(ns);
            if (socket.Connected)
            {
                int flag = 0;
                try
                {
                    int i = 0;
                    byte[] b = new byte[1920 * 1080];   //设置接收的大小
                    MemoryStream ms = null;
                    while (true)
                    {

                        byte[] b1 = new byte[1024 * 256];   //设置接收的大小 
                        byte[] b2 = new byte[1024 * 256];   //设置接收的大小 

                        i = this.socket.Receive(b);//接收 
                        //把byte[]转化成内存流,在把内存流转化成Image, 
                        ms = new MemoryStream(b, 0, i);
                        flag++;

                        System.Drawing.Image myimage = System.Drawing.Image.FromStream(ms);
                        //Bitmap bt = new Bitmap(ms);
                        showScreen.Image = myimage; //显示 
                        ms.Close();
                        ms.Dispose();  //释放占用资源
                        System.GC.Collect();//垃圾回收
                    }

                }
                catch (Exception ex)
                {
                    this.tcp.Stop();
                    MessageBox.Show("捕捉屏幕出错!server" + ex.Message + flag.ToString());
                }
            }
        }

        private void TCPMonitor_Load(object sender, EventArgs e)
        {
            tcpThread = new Thread(new ThreadStart(getRemote));
            tcpThread.Start();
        }
    }
}
