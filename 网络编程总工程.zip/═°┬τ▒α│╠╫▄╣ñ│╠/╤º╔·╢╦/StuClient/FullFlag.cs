﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StuClient
{
    class FullFlag
    {
        private static byte[] arrayFlag = new byte[1024];
        private static byte[] flag = { 1, 3, 7, 15, 31, 63, 127, 255 };

        public FullFlag()
        {
            clear();
        }



        public void clear()
        {
            for(int i=0; i<1024; i++)
            {
                arrayFlag[i] = 0;
            }
        }


        public void set(uint seqNum)
        {
            uint blockNum = seqNum / 8;
            byte blockIndex = (byte)(seqNum % 8);

            arrayFlag[blockNum] |= (byte)(1 << blockIndex);
        }


        public bool isEmpty()
        {
            for (int i = 0; i < 1024; i++)
            {
                if (arrayFlag[i] != 0)
                {
                    return false;
                }
            }

            return true;
        }



        public bool isFull(uint pieceCount)
        {
            uint blockNum = pieceCount / 8;
            byte blockIndex = (byte)(pieceCount % 8);

            if (blockNum == 0)
            {
                if (arrayFlag[0] == flag[blockIndex])
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                for (uint i = 0; i < blockNum; i++)
                {
                    if (arrayFlag[i] != flag[7])
                    {
                        return false;
                    }
                }

                if (arrayFlag[blockNum] == flag[blockIndex])
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;   //此处应该永远处理不到，防止异常产生以防万一.

        }

    }

    }

